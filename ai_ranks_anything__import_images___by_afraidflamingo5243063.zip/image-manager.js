import { rankingManager } from './ranking-manager.js';
import { chatManager } from './chat-manager.js';

export class ImageManager {
  async handleImageUpload() {
    const fileInput = document.getElementById('imageInput');
    const nameInput = document.getElementById('imageNameInput');
    const files = Array.from(fileInput.files);
    const messageBar = document.getElementById('messageBar');

    if (!files.length) {
      messageBar.textContent = 'Please select at least one image!';
      return;
    }

    let names = nameInput.value.trim() 
      ? nameInput.value.split(',').map(name => name.trim()) 
      : [];

    const addButton = document.querySelector('.add-button');
    const uploadButton = document.querySelector('.upload-button');
    nameInput.disabled = true;
    fileInput.disabled = true;
    uploadButton.disabled = true;
    addButton.disabled = true;
    uploadButton.classList.add('loading');

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        messageBar.textContent = `Processing image ${i + 1} of ${files.length}...`;

        const rawDataUrl = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target.result);
          reader.readAsDataURL(file);
        });
        
        const imageDataUrl = await this.compressImageDataUrl(rawDataUrl);

        let itemName = names[i];
        
        if (!itemName) {
          messageBar.textContent = `Analyzing image ${i + 1} and generating a name...`;
          try {
            const completion = await chatManager.chat([
              {
                role: "system",
                content: `You are a helpful assistant that names images.
                  Respond directly with JSON: { "name": "brief descriptive name (3-5 words)" }`
              },
              {
                role: "user",
                content: [
                  { type: "text", text: "Please give this image a descriptive name:" },
                  { type: "image_url", image_url: { url: imageDataUrl } }
                ]
              }
            ], true);
            
            const result = JSON.parse(completion.content);
            itemName = result.name;
          } catch (error) {
            console.error('Error generating name:', error);
            itemName = file.name.replace(/\.[^/.]+$/, "");
          }
        }

        messageBar.textContent = `Ranking image ${i + 1}: "${itemName}"...`;
        
        const result = await rankingManager.rankItem(itemName, imageDataUrl);
        
        const itemElement = document.createElement('div');
        itemElement.className = 'item with-image';
        itemElement.draggable = true;
        itemElement.ondragstart = window.dragManager.drag;
        itemElement.onclick = window.itemManager.showItemReason;
        
        const img = document.createElement('img');
        img.src = imageDataUrl;
        img.className = 'item-thumbnail';
        
        const label = document.createElement('div');
        label.className = 'item-label';
        label.textContent = itemName;
        
        itemElement.appendChild(img);
        itemElement.appendChild(label);
        itemElement.title = result.reasoning;

        const tierClass = result.tier.toLowerCase();
        const tierItems = document.querySelector(`.tier.${tierClass} .tier-items`);
        tierItems.appendChild(itemElement);
        
        if (i === files.length - 1) {
          messageBar.textContent = `Finished ranking ${files.length} images! Last image "${itemName}" ranked as tier ${result.tier} because: ${result.reasoning}`;
        }
      }

      nameInput.value = '';
      fileInput.value = '';
    } catch (error) {
      console.error('Error ranking images:', error);
      messageBar.textContent = 'Oops! Something went wrong while ranking the images.';
    } finally {
      nameInput.disabled = false;
      fileInput.disabled = false;
      uploadButton.disabled = false;
      addButton.disabled = false;
      uploadButton.classList.remove('loading');
    }
  }

  async compressImageDataUrl(dataUrl, maxWidthHeight = 800) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = function() {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidthHeight || height > maxWidthHeight) {
          if (width > height) {
            height *= maxWidthHeight / width;
            width = maxWidthHeight;
          } else {
            width *= maxWidthHeight / height;
            height = maxWidthHeight;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.src = dataUrl;
    });
  }
}

export const imageManager = new ImageManager();