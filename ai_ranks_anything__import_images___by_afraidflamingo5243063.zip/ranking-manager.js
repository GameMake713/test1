import { chatManager } from './chat-manager.js';

export class RankingManager {
  async rankItem(item, imageDataUrl = null) {
    const topic = document.getElementById('topicInput').value.trim() || 'general';
    const customPrompt = document.getElementById('promptInput').value.trim();
    
    let systemPrompt = `You are a tier list ranking assistant. Rank items on a scale from S (best) to F (worst).
      Current topic: ${topic}`;
      
    if (customPrompt) {
      systemPrompt += `\nRanking criteria: ${customPrompt}`;
    }
    
    const messages = [
      {
        role: "system",
        content: systemPrompt + `\nRespond directly with JSON in this format:
          {
            "tier": "S|A|B|C|D|E|F",
            "reasoning": "brief explanation"
          }`
      }
    ];

    if (imageDataUrl) {
      messages.push({
        role: "user",
        content: [
          { type: "text", text: `Rank this ${topic} item: ${item}` },
          { type: "image_url", image_url: { url: imageDataUrl } }
        ]
      });
    } else {
      messages.push({
        role: "user",
        content: `Rank this ${topic} item: ${item}`
      });
    }

    const completion = await chatManager.chat(messages, true);
    return JSON.parse(completion.content);
  }

  async rankItemPosition(item1Text, item2Text) {
    const topic = document.getElementById('topicInput').value.trim() || 'general';
    const customPrompt = document.getElementById('promptInput').value.trim();
    
    const messages = [
      {
        role: "system",
        content: `You are a ranking assistant. Compare two items and determine their relative order.
          Current topic: ${topic}
          ${customPrompt ? `\nRanking criteria: ${customPrompt}` : ''}
          \nRespond directly with JSON: { "firstIsGreater": boolean }`
      },
      {
        role: "user",
        content: `Compare these two items: "${item1Text}" and "${item2Text}". Should "${item1Text}" be placed to the right of "${item2Text}"?`
      }
    ];

    const completion = await chatManager.chat(messages, true);
    return JSON.parse(completion.content).firstIsGreater;
  }

  async sortTierItems(tierElement) {
    const items = Array.from(tierElement.children);
    const messageBar = document.getElementById('messageBar');
    const tierLabel = tierElement.closest('.tier').querySelector('.tier-label').textContent;
    
    messageBar.textContent = `Sorting items in tier ${tierLabel}...`;
    tierElement.dataset.sorted = 'true';

    // Bubble sort with AI comparisons
    for (let i = 0; i < items.length; i++) {
      for (let j = 0; j < items.length - i - 1; j++) {
        const item1Text = items[j].classList.contains('with-image') 
          ? items[j].querySelector('.item-label').textContent 
          : items[j].textContent;
        const item2Text = items[j + 1].classList.contains('with-image')
          ? items[j + 1].querySelector('.item-label').textContent 
          : items[j + 1].textContent;
        
        const shouldSwap = await this.rankItemPosition(item1Text, item2Text);
        
        if (shouldSwap) {
          items[j].style.order = j + 1;
          items[j + 1].style.order = j;
          [items[j], items[j + 1]] = [items[j + 1], items[j]];
        } else {
          items[j].style.order = j;
        }
      }
    }

    messageBar.textContent = `Finished sorting tier ${tierLabel}!`;
  }
}

export const rankingManager = new RankingManager();