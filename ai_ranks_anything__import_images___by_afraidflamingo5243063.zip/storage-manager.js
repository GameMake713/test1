export class StorageManager {
  saveTierList() {
    const saveNameInput = document.getElementById('saveNameInput');
    const saveName = saveNameInput.value.trim();
    const messageBar = document.getElementById('messageBar');
    
    if (!saveName) {
      messageBar.textContent = 'Please enter a name for your tier list!';
      return;
    }

    const tierList = {
      name: saveName,
      topic: document.getElementById('topicInput').value,
      prompt: document.getElementById('promptInput').value,
      customTiers: JSON.parse(localStorage.getItem('customTiers') || '[]'),
      tiers: {}
    };

    const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
    tiers.forEach(tier => {
      const tierItems = document.querySelector(`.tier.${tier.label.toLowerCase()} .tier-items`).children;
      tierList.tiers[tier.label.toLowerCase()] = Array.from(tierItems).map(item => ({
        html: item.outerHTML,
        title: item.title
      }));
    });

    try {
      const dataString = JSON.stringify(tierList);
      const sizeInMB = (new Blob([dataString]).size / 1024 / 1024).toFixed(2);
      
      if (sizeInMB > 4) {
        messageBar.textContent = `Warning: This tier list is quite large (${sizeInMB}MB). Try reducing the number of images or their quality.`;
        return;
      }

      let savedLists = JSON.parse(localStorage.getItem('tierLists') || '{}');
      
      const totalDataString = JSON.stringify({...savedLists, [saveName]: tierList});
      const totalSizeInMB = (new Blob([totalDataString]).size / 1024 / 1024).toFixed(2);
      
      if (totalSizeInMB > 4.5) {
        messageBar.textContent = `Error: Not enough storage space. Try deleting some old tier lists first. (Total size would be ${totalSizeInMB}MB)`;
        return;
      }

      savedLists[saveName] = tierList;
      localStorage.setItem('tierLists', JSON.stringify(savedLists));

      this.updateLoadSelect();
      messageBar.textContent = `Tier list "${saveName}" has been saved! (Size: ${sizeInMB}MB)`;
      saveNameInput.value = '';
      
    } catch (error) {
      if (error.name === 'QuotaExceededError') {
        messageBar.textContent = 'Error: Storage is full. Please delete some old tier lists before saving new ones.';
      } else {
        messageBar.textContent = 'Error: Could not save tier list. ' + error.message;
      }
      console.error('Save error:', error);
    }
  }

  updateLoadSelect() {
    const loadSelect = document.getElementById('loadSelect');
    const savedLists = JSON.parse(localStorage.getItem('tierLists') || '{}');
    
    while (loadSelect.options.length > 1) {
      loadSelect.remove(1);
    }

    Object.keys(savedLists).forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      loadSelect.appendChild(option);
    });
  }

  loadTierList() {
    const loadSelect = document.getElementById('loadSelect');
    const selectedName = loadSelect.value;
    const messageBar = document.getElementById('messageBar');
    
    if (!selectedName) {
      messageBar.textContent = 'Please select a tier list to load!';
      return;
    }

    const savedLists = JSON.parse(localStorage.getItem('tierLists') || '{}');
    const tierList = savedLists[selectedName];

    if (!tierList) {
      messageBar.textContent = 'Could not find the selected tier list!';
      return;
    }

    document.getElementById('topicInput').value = tierList.topic;

    const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
    tiers.forEach(tier => {
      const tierItems = document.querySelector(`.tier.${tier.label.toLowerCase()} .tier-items`);
      tierItems.innerHTML = '';
    });

    if (tierList.customTiers) {
      localStorage.setItem('customTiers', JSON.stringify(tierList.customTiers));
    }
    
    Object.entries(tierList.tiers).forEach(([tier, items]) => {
      const tierItems = document.querySelector(`.tier.${tier} .tier-items`);
      if (tierItems) {
        items.forEach(item => {
          const temp = document.createElement('div');
          temp.innerHTML = item.html;
          const itemElement = temp.firstChild;
          itemElement.title = item.title;
          itemElement.draggable = true;
          itemElement.ondragstart = window.dragManager.drag;
          itemElement.onclick = window.itemManager.showItemReason;
          tierItems.appendChild(itemElement);
        });
      }
    });
    
    messageBar.textContent = `Loaded tier list "${selectedName}"!`;
  }

  deleteTierList() {
    const loadSelect = document.getElementById('loadSelect');
    const selectedName = loadSelect.value;
    const messageBar = document.getElementById('messageBar');
    
    if (!selectedName) {
      messageBar.textContent = 'Please select a tier list to delete!';
      return;
    }

    const savedLists = JSON.parse(localStorage.getItem('tierLists') || '{}');
    delete savedLists[selectedName];
    localStorage.setItem('tierLists', JSON.stringify(savedLists));

    this.updateLoadSelect();
    messageBar.textContent = `Deleted tier list "${selectedName}"!`;
    loadSelect.value = '';
  }

  newTierList() {
    const messageBar = document.getElementById('messageBar');
    
    document.getElementById('topicInput').value = '';
    document.getElementById('promptInput').value = '';
    
    const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
    tiers.forEach(tier => {
      const tierItems = document.querySelector(`.tier.${tier.label.toLowerCase()} .tier-items`);
      tierItems.innerHTML = '';
    });
    
    document.getElementById('itemInput').value = '';
    document.getElementById('imageNameInput').value = '';
    document.getElementById('imageInput').value = '';
    document.getElementById('saveNameInput').value = '';
    document.getElementById('loadSelect').value = '';
    
    messageBar.textContent = 'Created new tier list! Enter a topic to get started.';
    document.getElementById('topicInput').focus();
  }
}

export const storageManager = new StorageManager();