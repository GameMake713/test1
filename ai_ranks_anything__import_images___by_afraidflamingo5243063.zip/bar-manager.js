// Bar size configurations
const barSizes = {
  small: { width: '50px', height: '40px' },
  medium: { width: '80px', height: '40px' },
  large: { width: '120px', height: '40px' },
  xl: { width: '160px', height: '40px' }
};

function updateBarSizes(size) {
  const items = document.querySelectorAll('.item:not(.with-image)');
  const messageBar = document.getElementById('messageBar');
  
  items.forEach(item => {
    item.style.width = barSizes[size].width;
    item.style.height = barSizes[size].height;
  });
  
  localStorage.setItem('preferredBarSize', size);
  messageBar.textContent = `Updated bar size to ${size}`;
}

function initializeBarSizes() {
  const savedSize = localStorage.getItem('preferredBarSize') || 'medium';
  updateBarSizes(savedSize);
  
  // Set the select to the saved value
  const sizeSelect = document.getElementById('barSizeSelect');
  if (sizeSelect) {
    sizeSelect.value = savedSize;
  }
}

export {
  updateBarSizes,
  initializeBarSizes
};

