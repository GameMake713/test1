import { rankingManager } from './ranking-manager.js';

export class ItemManager {
  async addItem() {
    const input = document.getElementById('itemInput');
    const topicInput = document.getElementById('topicInput');
    const addButton = document.querySelector('.add-button');
    const messageBar = document.getElementById('messageBar');
    const itemsString = input.value.trim();
    const topic = topicInput.value.trim();
    
    if (!itemsString) return;
    
    if (!topic) {
      messageBar.textContent = 'Please enter a topic for the tier list first!';
      topicInput.focus();
      return;
    }

    const items = itemsString.split(',').map(item => item.trim()).filter(item => item);

    input.disabled = true;
    addButton.disabled = true;
    addButton.classList.add('loading');
    messageBar.textContent = 'Thinking...';
    
    try {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        messageBar.textContent = `Ranking item ${i + 1} of ${items.length}: "${item}"...`;
        
        const result = await rankingManager.rankItem(item);
        
        const itemElement = document.createElement('div');
        itemElement.className = 'item';
        itemElement.draggable = true;
        itemElement.ondragstart = window.dragManager.drag;
        itemElement.onclick = this.showItemReason;
        itemElement.textContent = item;
        itemElement.title = result.reasoning;

        const tierClass = result.tier.toLowerCase();
        const tierItems = document.querySelector(`.tier.${tierClass} .tier-items`);
        tierItems.appendChild(itemElement);
        
        if (i === items.length - 1) {
          messageBar.textContent = `Finished ranking ${items.length} items! Last item "${item}" ranked as tier ${result.tier} because: ${result.reasoning}`;
        }
      }
      
      input.value = '';
    } catch (error) {
      console.error('Error ranking items:', error);
      messageBar.textContent = 'Oops! Something went wrong while ranking those items.';
    } finally {
      input.disabled = false;
      addButton.disabled = false;
      addButton.classList.remove('loading');
      input.focus();
    }
  }

  showItemReason(event) {
    const item = event.target.closest('.item');
    if (item) {
      const messageBar = document.getElementById('messageBar');
      const itemName = item.classList.contains('with-image') 
        ? item.querySelector('.item-label').textContent 
        : item.textContent;
      const reason = item.title;
      const tierLabel = item.closest('.tier').querySelector('.tier-label').textContent;
      messageBar.textContent = `I ranked "${itemName}" as tier ${tierLabel} because: ${reason}`;
    }
  }
}

export const itemManager = new ItemManager();

