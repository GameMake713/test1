export class ChatManager {
  constructor() {
    this.conversationHistory = [];
  }

  async chat(messages, json = false) {
    // Add messages to history
    this.conversationHistory.push(...messages);
    // Keep only last 10 messages
    this.conversationHistory = this.conversationHistory.slice(-10);
    
    return await websim.chat.completions.create({
      messages: this.conversationHistory,
      json
    });
  }
}

export const chatManager = new ChatManager();