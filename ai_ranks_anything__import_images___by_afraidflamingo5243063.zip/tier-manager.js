// Functions moved from script.js
function initializeTierManagement() {
  const defaultTiers = [
    { label: 'S', color: '#ff7f7f' },
    { label: 'A', color: '#ffbf7f' },
    { label: 'B', color: '#ffff7f' },
    { label: 'C', color: '#7fff7f' },
    { label: 'D', color: '#7f7fff' },
    { label: 'E', color: '#bf7fff' },
    { label: 'F', color: '#ff7fbf' }
  ];

  if (!localStorage.getItem('customTiers')) {
    localStorage.setItem('customTiers', JSON.stringify(defaultTiers));
  }

  renderTiers();
  
  const tiers = document.querySelectorAll('.tier-items');
  tiers.forEach(tier => {
    tier.dataset.sorted = 'false';
  });
}

function renderTiers() {
  const tierList = document.querySelector('.tier-list');
  tierList.innerHTML = '';
  
  const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
  
  tiers.forEach(tier => {
    const tierDiv = document.createElement('div');
    tierDiv.className = `tier ${tier.label.toLowerCase()}`;
    tierDiv.dataset.tier = tier.label;
    
    tierDiv.innerHTML = `
      <div class="tier-label" style="background-color: ${tier.color}">${tier.label}</div>
      <div class="tier-items" ondrop="drop(event)" ondragover="allowDrop(event)" data-sorted="false"></div>
      <button class="edit-tier" onclick="editTier('${tier.label}')">Edit</button>
      <button class="sort-tier" onclick="sortTierItems(this.closest('.tier').querySelector('.tier-items'))">Sort Items →</button>
    `;
    
    tierList.appendChild(tierDiv);
  });
}

function addTier() {
  const label = document.getElementById('newTierLabel').value.trim().toUpperCase();
  const color = document.getElementById('newTierColor').value;
  const messageBar = document.getElementById('messageBar');
  
  if (!label) {
    messageBar.textContent = 'Please enter a tier label!';
    return;
  }
  
  const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
  
  if (tiers.some(t => t.label === label)) {
    messageBar.textContent = 'A tier with that label already exists!';
    return;
  }
  
  tiers.push({ label, color });
  localStorage.setItem('customTiers', JSON.stringify(tiers));
  
  renderTiers();
  document.getElementById('newTierLabel').value = '';
  messageBar.textContent = `Added new tier ${label}!`;
}

function editTier(label) {
  const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
  const tier = tiers.find(t => t.label === label);
  const messageBar = document.getElementById('messageBar');
  
  if (!tier) {
    messageBar.textContent = 'Error: Could not find tier to edit';
    return;
  }

  const oldTierElement = document.querySelector(`[data-tier="${label}"]`);
  
  if (!oldTierElement) {
    messageBar.textContent = 'Error: Could not find tier element to edit';
    return;
  }
  
  const newLabel = prompt('Enter new label for tier:', tier.label);
  if (!newLabel) return;
  
  const newColor = prompt('Enter new color (hex or name):', tier.color);
  if (!newColor) return;
  
  const oldTierItems = oldTierElement.querySelector('.tier-items');
  const items = oldTierItems ? Array.from(oldTierItems.children) : [];
  
  tier.label = newLabel.trim().toUpperCase();
  tier.color = newColor;
  
  localStorage.setItem('customTiers', JSON.stringify(tiers));
  renderTiers();
  
  const newTierItems = document.querySelector(`[data-tier="${tier.label}"] .tier-items`);
  if (newTierItems && items.length > 0) {
    items.forEach(item => newTierItems.appendChild(item));
  }
  
  messageBar.textContent = `Updated tier ${label} to ${tier.label}!`;
}

function removeTier() {
  const label = document.getElementById('removeTierLabel').value.trim().toUpperCase();
  const messageBar = document.getElementById('messageBar');
  
  if (!label) {
    messageBar.textContent = 'Please enter a tier label to remove!';
    return;
  }
  
  const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
  const tierIndex = tiers.findIndex(t => t.label === label);
  
  if (tierIndex === -1) {
    messageBar.textContent = 'Tier not found!';
    return;
  }
  
  const tierItems = document.querySelector(`[data-tier="${label}"] .tier-items`);
  if (tierItems && tiers.length > 1) {
    const defaultTier = document.querySelector(`[data-tier="${tiers[0].label}"] .tier-items`);
    Array.from(tierItems.children).forEach(item => defaultTier.appendChild(item));
  }
  
  tiers.splice(tierIndex, 1);
  localStorage.setItem('customTiers', JSON.stringify(tiers));
  
  renderTiers();
  document.getElementById('removeTierLabel').value = '';
  messageBar.textContent = `Removed tier ${label}!`;
}

function resetTiers() {
  const messageBar = document.getElementById('messageBar');
  const defaultTiers = [
    { label: 'S', color: '#ff7f7f' },
    { label: 'A', color: '#ffbf7f' },
    { label: 'B', color: '#ffff7f' },
    { label: 'C', color: '#7fff7f' },
    { label: 'D', color: '#7f7fff' },
    { label: 'E', color: '#bf7fff' },
    { label: 'F', color: '#ff7fbf' }
  ];

  const currentItems = {};
  const tiers = JSON.parse(localStorage.getItem('customTiers') || '[]');
  tiers.forEach(tier => {
    const tierItems = document.querySelector(`[data-tier="${tier.label}"] .tier-items`);
    if (tierItems) {
      currentItems[tier.label] = Array.from(tierItems.children);
    }
  });

  localStorage.setItem('customTiers', JSON.stringify(defaultTiers));
  renderTiers();

  Object.entries(currentItems).forEach(([oldTier, items]) => {
    const defaultTier = defaultTiers.find(t => t.label === oldTier) || defaultTiers[0];
    const newTierItems = document.querySelector(`[data-tier="${defaultTier.label}"] .tier-items`);
    items.forEach(item => newTierItems.appendChild(item));
  });

  messageBar.textContent = 'Tiers have been reset to default configuration!';
}

export {
  initializeTierManagement,
  renderTiers,
  addTier,
  editTier,
  removeTier,
  resetTiers
};