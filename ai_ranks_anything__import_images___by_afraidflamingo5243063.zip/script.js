let conversationHistory = [];

document.addEventListener('DOMContentLoaded', () => {
  // Add keyboard support for item input
  const input = document.getElementById('itemInput');
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      window.addItem();
    }
  });
  
  // Initialize all managers
  window.storageManager.updateLoadSelect();
  window.dragManager.initialize();
  window.tierManager.initializeTierManagement();
  window.barManager.initializeBarSizes();
});