export class DragManager {
  initialize() {
    // Add drag and drop event listeners to tier items
    const tierItems = document.querySelectorAll('.tier-items');
    tierItems.forEach(items => {
      items.ondrop = this.drop;
      items.ondragover = this.allowDrop;
    });
  }

  allowDrop(ev) {
    ev.preventDefault();
  }

  drag(ev) {
    ev.dataTransfer.setData("text", ev.target.outerHTML);
    ev.dataTransfer.effectAllowed = "move";
  }

  drop(ev) {
    ev.preventDefault();
    const data = ev.dataTransfer.getData("text");
    
    const temp = document.createElement('div');
    temp.innerHTML = data;
    const draggedElement = temp.firstChild;
    
    const dropZone = ev.target.classList.contains('tier-items') 
      ? ev.target 
      : ev.target.closest('.tier-items');

    if (dropZone) {
      // Remove the original element
      const allItems = document.querySelectorAll('.item');
      allItems.forEach(item => {
        if (item.textContent === draggedElement.textContent) {
          item.remove();
        }
      });

      // Calculate drop position
      const rect = dropZone.getBoundingClientRect();
      const x = ev.clientX - rect.left;
      const existingItems = Array.from(dropZone.children);
      
      let insertIndex = existingItems.findIndex(item => {
        const itemRect = item.getBoundingClientRect();
        return (itemRect.left - rect.left + itemRect.width / 2) > x;
      });
      
      if (insertIndex === -1) {
        dropZone.appendChild(draggedElement);
      } else {
        dropZone.insertBefore(draggedElement, existingItems[insertIndex]);
      }
      
      dropZone.dataset.sorted = 'false';
    }
  }
}

export const dragManager = new DragManager();